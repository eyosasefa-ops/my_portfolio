<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

class PortfolioTest extends TestCase
{
    public function test_the_portfolio_homepage_renders_its_main_sections(): void
    {
        $response = $this->get('/');

        $response
            ->assertOk()
            ->assertSee('Abera Asefa')
            ->assertSee('images/abera-profile.png')
            ->assertSee('Portrait of Abera Asefa')
            ->assertSee('Bule Hora University')
            ->assertSee('Bule Hora University (BHU)')
            ->assertSee('tel:+251940495256')
            ->assertSee('href="mailto:aberaasefa61@gmail.com"', false)
            ->assertSee('aberaasefa61@gmail.com')
            ->assertSee('Hawassa, Ethiopia')
            ->assertSee('Copy number')
            ->assertSee('Copy email')
            ->assertSee('Website Development')
            ->assertSee('id="resume"', false)
            ->assertSee('Problem it addresses')
            ->assertSee('Selected work')
            ->assertSee('Start a conversation');

        $this->assertSame(2, substr_count($response->getContent(), 'class="brand-profile-photo"'));
        $this->assertSame(1, substr_count($response->getContent(), 'class="profile-photo"'));
    }

    public function test_the_contact_form_validates_required_fields(): void
    {
        $this->from('/')
            ->post('/contact', ['email' => 'not-an-email'])
            ->assertRedirect('/')
            ->assertSessionHasErrors(['name', 'email', 'subject', 'inquiry_type', 'message']);
    }

    public function test_the_contact_form_reports_when_delivery_is_not_configured(): void
    {
        config(['portfolio.contact_email' => null]);

        $this->from('/')
            ->post('/contact', [
                'name' => 'Taylor Example',
                'email' => 'taylor@example.com',
                'subject' => 'A message from the portfolio',
                'inquiry_type' => 'Software Project Collaboration',
                'message' => 'I would like to discuss a possible collaboration.',
            ])
            ->assertRedirect('/')
            ->assertSessionHas('contact_error');
    }

    public function test_the_contact_form_sends_a_message_to_the_configured_recipient(): void
    {
        config(['portfolio.contact_email' => 'owner@example.com']);

        Mail::shouldReceive('raw')
            ->once()
            ->withArgs(fn (string $body, \Closure $callback): bool => str_contains($body, 'Inquiry type: Website Development') && str_contains($body, 'I would like to discuss a possible collaboration.') && is_callable($callback))
            ->andReturnNull();

        $this->from('/')
            ->post('/contact', [
                'name' => 'Taylor Example',
                'email' => 'taylor@example.com',
                'subject' => 'A message from the portfolio',
                'inquiry_type' => 'Website Development',
                'message' => 'I would like to discuss a possible collaboration.',
            ])
            ->assertRedirect('/')
            ->assertSessionHas('contact_success');
    }
}
