<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#101411">
    <meta name="description" content="<?php echo e($portfolio['name']); ?> is a <?php echo e($portfolio['field_of_study']); ?> student at <?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>), interested in web development and practical software projects.">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($portfolio['name']); ?> — <?php echo e($portfolio['title']); ?>">
    <meta property="og:description" content="<?php echo e($portfolio['name']); ?> — <?php echo e($portfolio['field_of_study']); ?> student at <?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>).">
    <?php if($portfolio['photo_path'] && file_exists(public_path($portfolio['photo_path']))): ?>
        <meta property="og:image" content="<?php echo e(asset($portfolio['photo_path'])); ?>">
    <?php endif; ?>
    <title><?php echo e($portfolio['name']); ?> | <?php echo e($portfolio['title']); ?> at <?php echo e($portfolio['university']); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/portfolio.css')); ?>">
    <script src="<?php echo e(asset('js/portfolio.js')); ?>" defer></script>
</head>
<body>
    <a class="skip-link" href="#main">Skip to content</a>
    <header class="site-header">
        <nav class="nav shell" aria-label="Main navigation">
            <a class="brand" href="#home" aria-label="<?php echo e($portfolio['name']); ?> home">
                <?php if($portfolio['photo_path'] && file_exists(public_path($portfolio['photo_path']))): ?>
                    <img class="brand-profile-photo" src="<?php echo e(asset($portfolio['photo_path'])); ?>" alt="">
                <?php else: ?>
                    <span class="brand-mark">A<span>.</span></span>
                <?php endif; ?>
                <span class="brand-name"><?php echo e($portfolio['name']); ?></span>
            </a>
            <button class="menu-toggle" type="button" aria-label="Open navigation menu" aria-expanded="false" aria-controls="nav-links">
                <span></span><span></span>
            </button>
            <div class="nav-links" id="nav-links">
                <a href="#about">About</a>
                <a href="#skills">Skills</a>
                <a href="#projects">Projects</a>
                <a href="#journey">Journey</a>
                <a href="#resume">CV</a>
                <a class="nav-contact-link" href="#contact">Contact me</a>
                <button class="theme-toggle" type="button" aria-label="Switch to light theme" title="Toggle color theme">
                    <span class="theme-icon" aria-hidden="true">☼</span>
                </button>
            </div>
        </nav>
    </header>

    <main id="main">
        <section class="hero shell" id="home" aria-labelledby="hero-title">
            <div class="hero-copy">
                <p class="eyebrow"><span class="status-dot"></span> <?php echo e($portfolio['field_of_study']); ?> student · <?php echo e($portfolio['university_abbreviation']); ?></p>
                <h1 id="hero-title">Building digital solutions.<br><span>Turning ideas into reality.</span></h1>
                <p class="hero-description"><?php echo e($portfolio['description']); ?></p>
                <p class="hero-role"><?php echo e($portfolio['title']); ?> · <?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</p>
                <div class="hero-actions">
                    <a class="button button-primary" href="#projects">Explore my work <span aria-hidden="true">↗</span></a>
                    <a class="button button-secondary" href="#contact">Let’s connect</a>
                    <a class="button button-text hero-email-link" href="mailto:<?php echo e($portfolio['email']); ?>?subject=<?php echo e(rawurlencode('Portfolio Inquiry — '.$portfolio['name'])); ?>">Email me <span aria-hidden="true">↗</span></a>
                    <?php if($portfolio['cv_path'] && file_exists(public_path($portfolio['cv_path']))): ?>
                        <a class="button button-text" href="<?php echo e(asset($portfolio['cv_path'])); ?>" download>Download CV <span aria-hidden="true">↓</span></a>
                    <?php else: ?>
                        <a class="button button-text" href="#resume">CV details <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                </div>
                <div class="hero-socials" aria-label="Professional profiles">
                    <?php if($portfolio['github_url']): ?>
                        <a href="<?php echo e($portfolio['github_url']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                    <?php if($portfolio['linkedin_url']): ?>
                        <a href="<?php echo e($portfolio['linkedin_url']); ?>" target="_blank" rel="noopener noreferrer">LinkedIn <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                    <?php if(! $portfolio['github_url'] && ! $portfolio['linkedin_url']): ?>
                        <span class="muted">Add your professional profile links in .env</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="hero-art<?php echo e($portfolio['photo_path'] && file_exists(public_path($portfolio['photo_path'])) ? ' has-portrait' : ''); ?>" aria-label="<?php echo e($portfolio['photo_path'] && file_exists(public_path($portfolio['photo_path'])) ? 'Profile portrait of '.$portfolio['name'] : 'Abstract developer illustration'); ?>">
                <div class="art-orbit orbit-one"></div>
                <div class="art-orbit orbit-two"></div>
                <div class="art-glow"></div>
                <?php if($portfolio['photo_path'] && file_exists(public_path($portfolio['photo_path']))): ?>
                    <figure class="profile-portrait">
                        <img class="profile-photo" src="<?php echo e(asset($portfolio['photo_path'])); ?>" alt="Portrait of <?php echo e($portfolio['name']); ?>">
                        <figcaption class="profile-caption">
                            <span><span class="status-dot"></span> Open to opportunities</span>
                            <strong><?php echo e($portfolio['name']); ?></strong>
                            <small>Software Engineering Student</small>
                        </figcaption>
                    </figure>
                <?php else: ?>
                    <div class="code-card">
                        <div class="code-card-top"><span></span><span></span><span></span><small>developer.js</small></div>
                        <div class="code-lines" aria-hidden="true">
                            <p><span class="code-purple">const</span> <span class="code-blue">developer</span> = {</p>
                            <p class="indent"><span class="code-green">name</span>: <span class="code-yellow">'<?php echo e($portfolio['name']); ?>'</span>,</p>
                            <p class="indent"><span class="code-green">focus</span>: [</p>
                            <p class="indent-more"><span class="code-yellow">'web development'</span>,</p>
                            <p class="indent-more"><span class="code-yellow">'problem solving'</span></p>
                            <p class="indent">],</p>
                            <p class="indent"><span class="code-green">mindset</span>: <span class="code-yellow">'always learning'</span></p>
                            <p>};</p>
                        </div>
                        <span class="code-cursor" aria-hidden="true"></span>
                    </div>
                    <div class="art-label art-label-top"><span class="label-icon">✳</span> Curious by nature</div>
                    <div class="art-label art-label-bottom"><span class="status-dot"></span> Open to opportunities</div>
                    <div class="avatar-placeholder" role="img" aria-label="Profile photo placeholder; add a photo in the portfolio settings">AA</div>
                <?php endif; ?>
                <span class="art-coordinate" aria-hidden="true">BUILDING WITH CURIOSITY</span>
            </div>
            <a class="scroll-cue" href="#about"><span></span> Scroll to explore</a>
        </section>

        <section class="section section-about" id="about" aria-labelledby="about-title">
            <div class="shell about-grid">
                <div class="section-heading">
                    <p class="eyebrow">01 / A little about me</p>
                    <h2 id="about-title">Curiosity is where<br>good work <span>begins.</span></h2>
                </div>
                <div class="about-content">
                    <p class="lead">Hello, I’m <?php echo e($portfolio['name']); ?>, a <?php echo e($portfolio['field_of_study']); ?> student at <?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>). I’m interested in creating software that makes everyday tasks clearer and easier.</p>
                    <p>I’m learning how to plan and build web applications, organize information in databases, and turn a real need into a useful digital solution. I value clear communication, thoughtful problem-solving, teamwork, and improving my code as I learn.</p>
                    <p>My interests include web development, responsive design, object-oriented programming, mobile applications, and exploring data and AI. I’m working toward becoming a dependable software engineer and contributing to meaningful technology projects.</p>
                    <div class="interest-list" aria-label="Technical interests">
                        <?php $__currentLoopData = $portfolio['interests']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($interest); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="about-profile-card">
                        <h3>A quick introduction</h3>
                        <dl>
                            <div><dt>Name</dt><dd><?php echo e($portfolio['name']); ?></dd></div>
                            <div><dt>University</dt><dd><?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</dd></div>
                            <div><dt>Field of study</dt><dd><?php echo e($portfolio['field_of_study']); ?></dd></div>
                            <div><dt>Professional focus</dt><dd><?php echo e($portfolio['professional_focus']); ?></dd></div>
                            <div><dt>Career objective</dt><dd><?php echo e($portfolio['career_objective']); ?></dd></div>
                        </dl>
                    </div>
                    <div class="about-facts">
                        <?php if($portfolio['location']): ?>
                            <div><span class="fact-icon">⌖</span><span><small>Based in</small><?php echo e($portfolio['location']); ?></span></div>
                        <?php endif; ?>
                        <div><span class="fact-icon">⌘</span><span><small>Currently focused on</small>Software engineering</span></div>
                        <div><span class="fact-icon">↗</span><span><small>Looking for</small>Learning opportunities</span></div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section" id="skills" aria-labelledby="skills-title">
            <div class="shell">
                <div class="section-heading section-heading-row">
                    <div>
                        <p class="eyebrow">02 / Tools in my toolbox</p>
                        <h2 id="skills-title">Learning by <span>building.</span></h2>
                    </div>
                    <p class="section-note">I’m building my skills through study and practice. “Foundations” describes what I’m learning to use; other groups show technologies I’m currently learning or exploring, not advanced proficiency.</p>
                </div>
                <div class="skill-grid">
                    <?php $__currentLoopData = $portfolio['skills']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="skill-card">
                            <span class="card-index">0<?php echo e($loop->iteration); ?></span>
                            <h3><?php echo e($group['category']); ?></h3>
                            <p class="skill-description"><?php echo e($group['description']); ?></p>
                            <div class="skill-tags">
                                <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($skill); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

        <section class="section section-projects" id="projects" aria-labelledby="projects-title">
            <div class="shell">
                <div class="section-heading section-heading-row">
                    <div>
                        <p class="eyebrow">03 / Selected work</p>
                        <h2 id="projects-title">Ideas with <span>purpose.</span></h2>
                    </div>
                    <p class="section-note">These academic project summaries explain the problem each idea addresses. Technology lists are suggestions or areas explored; links and implementation details appear only when verified.</p>
                </div>
                <div class="project-toolbar">
                    <div class="filter-list" role="group" aria-label="Filter projects by category">
                        <button class="filter-button is-active" type="button" data-filter="all" aria-pressed="true">All projects</button>
                        <button class="filter-button" type="button" data-filter="Web" aria-pressed="false">Web applications</button>
                        <button class="filter-button" type="button" data-filter="Systems" aria-pressed="false">Systems</button>
                    </div>
                    <label class="search-field">
                        <span class="visually-hidden">Search projects</span>
                        <span aria-hidden="true">⌕</span>
                        <input type="search" id="project-search" placeholder="Search projects" autocomplete="off">
                    </label>
                </div>
                <div class="project-grid" id="project-grid">
                    <?php $__currentLoopData = $portfolio['projects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="project-card" data-category="<?php echo e($project['category']); ?>" data-search="<?php echo e(strtolower($project['title'].' '.$project['summary'].' '.implode(' ', $project['stack']))); ?>">
                            <div class="project-visual project-visual-<?php echo e(($loop->index % 4) + 1); ?>">
                                <span class="project-number">0<?php echo e($loop->iteration); ?></span>
                                <span class="project-visual-mark" aria-hidden="true"><?php echo e(str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT)); ?></span>
                                <span class="project-category"><?php echo e($project['stage']); ?></span>
                            </div>
                            <div class="project-content">
                                <h3><?php echo e($project['title']); ?></h3>
                                <p><?php echo e($project['summary']); ?></p>
                                <p class="project-stack-label"><?php echo e($project['stack_note']); ?></p>
                                <div class="project-tags">
                                    <?php $__currentLoopData = $project['stack']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technology): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><?php echo e($technology); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="project-actions">
                                    <button class="project-details-button" type="button"
                                        data-title="<?php echo e($project['title']); ?>"
                                        data-details="<?php echo e($project['details']); ?>"
                                        data-problem="<?php echo e($project['problem']); ?>"
                                        data-objective="<?php echo e($project['objective']); ?>"
                                        data-contribution="<?php echo e($project['contribution']); ?>"
                                        data-stack="<?php echo e(implode(', ', $project['stack'])); ?>"
                                        data-stack-note="<?php echo e($project['stack_note']); ?>"
                                        data-features="<?php echo e(implode('|', $project['features'])); ?>">
                                        View details <span aria-hidden="true">↗</span>
                                    </button>
                                    <?php if($project['github']): ?>
                                        <a href="<?php echo e($project['github']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span aria-hidden="true">↗</span></a>
                                    <?php endif; ?>
                                    <?php if($project['demo']): ?>
                                        <a href="<?php echo e($project['demo']); ?>" target="_blank" rel="noopener noreferrer">Live demo <span aria-hidden="true">↗</span></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p class="empty-projects" id="empty-projects" hidden>No projects match your search.</p>
                </div>
            </div>
        </section>

        <section class="section" id="journey" aria-labelledby="journey-title">
            <div class="shell journey-grid">
                <div class="section-heading">
                    <p class="eyebrow">04 / The learning journey</p>
                    <h2 id="journey-title">Foundations for<br>what comes <span>next.</span></h2>
                    <p class="section-note">I value steady progress, practical experience, and learning from every project.</p>
                </div>
                <div class="journey-content">
                    <article class="timeline-item">
                        <span class="timeline-marker"></span>
                        <p class="timeline-label">Education</p>
                        <h3><?php echo e($portfolio['education']['institution']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</h3>
                        <p><?php echo e($portfolio['education']['program']); ?></p>
                        <span class="timeline-date"><?php echo e($portfolio['education']['status']); ?></span>
                        <div class="course-tags">
                            <?php $__currentLoopData = $portfolio['education']['coursework']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($course); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </article>
                    <article class="timeline-item">
                        <span class="timeline-marker"></span>
                        <p class="timeline-label">Learning background</p>
                        <h3>Areas of study</h3>
                        <p>Building knowledge across software development, data, and emerging technologies.</p>
                        <div class="course-tags">
                            <?php $__currentLoopData = $portfolio['learning_background']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($subject); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </article>
                    <article class="timeline-item">
                        <span class="timeline-marker"></span>
                        <p class="timeline-label">Hands-on learning</p>
                        <h3>Learning through academic projects</h3>
                        <p>Using project work to explore application workflows, client-server communication, and thoughtful data organization. I describe project status and my individual contribution clearly.</p>
                        <span class="timeline-date">Ongoing</span>
                    </article>
                    <div class="journey-callout">
                        <span aria-hidden="true">✳</span>
                        <p><strong>Always learning.</strong><br>Every project is a chance to ask better questions and build a stronger foundation.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="section section-services" id="services" aria-labelledby="services-title">
            <div class="shell">
                <div class="section-heading">
                    <p class="eyebrow">05 / Skills I’m developing</p>
                    <h2 id="services-title">Areas I’m working <span>toward.</span></h2>
                </div>
                <div class="services-grid">
                    <article><span>01 / Learning focus</span><h3>Responsive websites</h3><p>Practicing layouts that make information easy to read and use on phones, tablets, and desktop screens.</p></article>
                    <article><span>02 / Learning focus</span><h3>Web applications</h3><p>Exploring how application features can support real tasks through clear, dependable workflows.</p></article>
                    <article><span>03 / Learning focus</span><h3>Database design</h3><p>Learning to structure related information so it can be stored and retrieved reliably.</p></article>
                    <article><span>04 / Learning focus</span><h3>Mobile and emerging technology</h3><p>Growing my interest in mobile development, data analysis, and AI through ongoing study.</p></article>
                </div>
            </div>
        </section>

        <section class="section section-resume" id="resume" aria-labelledby="resume-title">
            <div class="shell resume-card">
                <div class="resume-copy">
                    <p class="eyebrow">06 / Resume</p>
                    <h2 id="resume-title">A clear picture of<br>my <span>background.</span></h2>
                    <p>My resume brings together my education at <?php echo e($portfolio['university']); ?>, Software Engineering studies, technical skills, and academic projects.</p>
                    <?php if($portfolio['cv_path'] && file_exists(public_path($portfolio['cv_path']))): ?>
                        <a class="button button-primary" href="<?php echo e(asset($portfolio['cv_path'])); ?>" download>Download my CV (PDF) <span aria-hidden="true">↓</span></a>
                    <?php else: ?>
                        <p class="resume-note">A downloadable PDF isn’t available yet. Please contact me if you’d like to discuss my background.</p>
                        <a class="button button-secondary" href="#contact">Ask me about my background <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                </div>
                <div class="resume-highlights">
                    <div><span>Education</span><strong><?php echo e($portfolio['education']['program']); ?></strong><small><?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</small></div>
                    <div><span>Focus</span><strong><?php echo e($portfolio['professional_focus']); ?></strong><small><?php echo e($portfolio['education']['status']); ?></small></div>
                    <div><span>Project work</span><strong>Academic software projects</strong><small>Project scope and technologies are identified transparently.</small></div>
                </div>
            </div>
        </section>

        <section class="section section-contact" id="contact" aria-labelledby="contact-title">
            <div class="shell contact-grid">
                <div class="contact-copy">
                    <p class="eyebrow">07 / Start a conversation</p>
                    <h2 id="contact-title">Have an idea?<br><span>Let’s talk.</span></h2>
                    <p>I’m open to internship and learning opportunities, academic collaboration, and conversations about suitable project work. Tell me what you have in mind, and we can discuss the scope together.</p>
                    <?php if($portfolio['email']): ?>
                        <a class="contact-email" href="mailto:<?php echo e($portfolio['email']); ?>"><?php echo e($portfolio['email']); ?> <span aria-hidden="true">↗</span></a>
                    <?php else: ?>
                        <p class="contact-email-note">Set your public email in the portfolio settings to show it here.</p>
                    <?php endif; ?>
                    <?php if($portfolio['location']): ?>
                        <p class="contact-location">⌖ &nbsp; <?php echo e($portfolio['location']); ?></p>
                    <?php endif; ?>
                    <div class="contact-socials">
                        <?php if($portfolio['github_url']): ?>
                            <a href="<?php echo e($portfolio['github_url']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span aria-hidden="true">↗</span></a>
                        <?php endif; ?>
                        <?php if($portfolio['linkedin_url']): ?>
                            <a href="<?php echo e($portfolio['linkedin_url']); ?>" target="_blank" rel="noopener noreferrer">LinkedIn <span aria-hidden="true">↗</span></a>
                        <?php endif; ?>
                    </div>
                </div>
                <form class="contact-form" action="<?php echo e(route('contact.store')); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="form-status" aria-live="polite" aria-atomic="true">
                        <?php if(session('contact_success')): ?>
                            <p class="form-message form-message-success"><?php echo e(session('contact_success')); ?></p>
                        <?php endif; ?>
                        <?php if(session('contact_error')): ?>
                            <p class="form-message form-message-error"><?php echo e(session('contact_error')); ?></p>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <p class="form-message form-message-error">Please check the highlighted fields and try again.</p>
                        <?php endif; ?>
                    </div>
                    <div class="form-row">
                        <div class="form-field">
                            <label for="name">Full name</label>
                            <input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" autocomplete="name" maxlength="100" required <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="name-error" aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error" id="name-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-field">
                            <label for="email">Email address</label>
                            <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="email" maxlength="254" required <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="email-error" aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error" id="email-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-field">
                        <label for="subject">Subject</label>
                        <input id="subject" name="subject" type="text" value="<?php echo e(old('subject')); ?>" maxlength="150" required <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="subject-error" aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error" id="subject-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="inquiry_type">What would you like to discuss?</label>
                        <select id="inquiry_type" name="inquiry_type" required <?php $__errorArgs = ['inquiry_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="inquiry_type-error" aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                            <option value="">Choose an inquiry type</option>
                            <?php $__currentLoopData = $portfolio['inquiry_types']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiryType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($inquiryType); ?>" <?php if(old('inquiry_type') === $inquiryType): echo 'selected'; endif; ?>><?php echo e($inquiryType); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['inquiry_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error" id="inquiry_type-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" rows="5" minlength="10" maxlength="5000" required <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-describedby="message-error" aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error" id="message-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-honeypot" aria-hidden="true">
                        <label for="website">Leave this field empty</label>
                        <input id="website" name="website" type="text" tabindex="-1" autocomplete="off">
                    </div>
                    <button class="button button-primary submit-button" type="submit">
                        <span class="submit-label">Send message</span><span aria-hidden="true">↗</span>
                    </button>
                    <p class="form-note">Your details are only used to reply to your message.</p>
                </form>
            </div>
            <div class="shell contact-cards" aria-label="Contact information">
                <article class="contact-card">
                    <span class="contact-card-icon" aria-hidden="true">☎</span>
                    <div class="contact-card-copy">
                        <h3>Call me</h3>
                        <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $portfolio['phone'])); ?>"><?php echo e($portfolio['phone']); ?></a>
                    </div>
                    <div class="contact-card-actions">
                        <a class="contact-action" href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $portfolio['phone'])); ?>">Call</a>
                        <button class="contact-action copy-button" type="button" data-copy="<?php echo e($portfolio['phone']); ?>" data-copy-label="Copy number">Copy number</button>
                    </div>
                </article>
                <article class="contact-card">
                    <span class="contact-card-icon" aria-hidden="true">✉</span>
                    <div class="contact-card-copy">
                        <h3>Email me</h3>
                        <a href="mailto:<?php echo e($portfolio['email']); ?>?subject=<?php echo e(rawurlencode('Portfolio Inquiry — '.$portfolio['name'])); ?>"><?php echo e($portfolio['email']); ?></a>
                    </div>
                    <div class="contact-card-actions">
                        <a class="contact-action" href="mailto:<?php echo e($portfolio['email']); ?>?subject=<?php echo e(rawurlencode('Portfolio Inquiry — '.$portfolio['name'])); ?>">Email</a>
                        <button class="contact-action copy-button" type="button" data-copy="<?php echo e($portfolio['email']); ?>" data-copy-label="Copy email">Copy email</button>
                    </div>
                </article>
                <article class="contact-card">
                    <span class="contact-card-icon" aria-hidden="true">⌖</span>
                    <div class="contact-card-copy">
                        <h3>Location</h3>
                        <p><?php echo e($portfolio['location']); ?></p>
                    </div>
                    <a class="contact-action" href="https://www.google.com/maps/search/?api=1&amp;query=<?php echo e(urlencode($portfolio['location'])); ?>" target="_blank" rel="noopener noreferrer">View map <span aria-hidden="true">↗</span></a>
                </article>
                <article class="contact-card">
                    <span class="contact-card-icon" aria-hidden="true">⌂</span>
                    <div class="contact-card-copy">
                        <h3>University</h3>
                        <p><?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</p>
                    </div>
                </article>
            </div>
            <p class="shell copy-feedback" id="copy-feedback" role="status" aria-live="polite" aria-atomic="true"></p>
        </section>
    </main>

    <footer class="site-footer">
        <div class="shell footer-main">
            <a class="brand" href="#home" aria-label="<?php echo e($portfolio['name']); ?> home">
                <?php if($portfolio['photo_path'] && file_exists(public_path($portfolio['photo_path']))): ?>
                    <img class="brand-profile-photo" src="<?php echo e(asset($portfolio['photo_path'])); ?>" alt="">
                <?php else: ?>
                    <span class="brand-mark">A<span>.</span></span>
                <?php endif; ?>
                <span class="brand-name"><?php echo e($portfolio['name']); ?></span>
            </a>
            <p><?php echo e($portfolio['field_of_study']); ?> student at <?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</p>
            <nav aria-label="Footer navigation">
                <a href="#about">About</a><a href="#projects">Projects</a><a href="#contact">Contact</a>
            </nav>
        </div>
        <div class="shell footer-contact">
            <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $portfolio['phone'])); ?>"><?php echo e($portfolio['phone']); ?></a>
            <a href="mailto:<?php echo e($portfolio['email']); ?>"><?php echo e($portfolio['email']); ?></a>
            <span><?php echo e($portfolio['location']); ?></span>
            <?php if($portfolio['github_url']): ?>
                <a href="<?php echo e($portfolio['github_url']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span aria-hidden="true">↗</span></a>
            <?php endif; ?>
            <?php if($portfolio['linkedin_url']): ?>
                <a href="<?php echo e($portfolio['linkedin_url']); ?>" target="_blank" rel="noopener noreferrer">LinkedIn <span aria-hidden="true">↗</span></a>
            <?php endif; ?>
        </div>
        <div class="shell footer-contact">
            <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $portfolio['phone'])); ?>"><?php echo e($portfolio['phone']); ?></a>
            <a href="mailto:<?php echo e($portfolio['email']); ?>"><?php echo e($portfolio['email']); ?></a>
            <span><?php echo e($portfolio['location']); ?></span>
            <?php if($portfolio['github_url']): ?>
                <a href="<?php echo e($portfolio['github_url']); ?>" target="_blank" rel="noopener noreferrer">GitHub <span aria-hidden="true">↗</span></a>
            <?php endif; ?>
            <?php if($portfolio['linkedin_url']): ?>
                <a href="<?php echo e($portfolio['linkedin_url']); ?>" target="_blank" rel="noopener noreferrer">LinkedIn <span aria-hidden="true">↗</span></a>
            <?php endif; ?>
        </div>
        <div class="shell footer-bottom">
            <span>© <?php echo e(now()->year); ?> <?php echo e($portfolio['name']); ?> | <?php echo e($portfolio['title']); ?> · <?php echo e($portfolio['university']); ?> (<?php echo e($portfolio['university_abbreviation']); ?>)</span>
            <a href="#home">Back to top ↑</a>
        </div>
        <div class="shell footer-closing">Designed with passion for technology, learning, and innovation.</div>
    </footer>

    <dialog class="project-dialog" aria-labelledby="dialog-title">
        <button class="dialog-close" type="button" aria-label="Close project details">×</button>
        <p class="eyebrow">Project details</p>
        <h2 id="dialog-title"></h2>
        <p class="dialog-description"></p>
        <h3>Problem it addresses</h3>
        <p class="dialog-problem"></p>
        <h3>Project objective</h3>
        <p class="dialog-objective"></p>
        <h3>Focus areas</h3>
        <ul class="dialog-features"></ul>
        <h3>My learning and contribution</h3>
        <p class="dialog-contribution"></p>
        <p class="dialog-stack"></p>
    </dialog>
    <button class="back-to-top" type="button" aria-label="Back to top">↑</button>
</body>
</html>
<?php /**PATH C:\Users\admin\Herd\my_portfolio\resources\views/welcome.blade.php ENDPATH**/ ?>