<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page not found — Abera Asefa</title>
    <link rel="stylesheet" href="{{ asset('css/portfolio.css') }}">
</head>
<body>
    <main class="not-found">
        <p class="eyebrow">404 / Page not found</p>
        <h1>This page took<br><span>a different path.</span></h1>
        <p>The page may have moved, or the link may be out of date.</p>
        <a class="button button-primary" href="{{ route('home') }}">Back to the portfolio <span aria-hidden="true">↗</span></a>
    </main>
</body>
</html>
