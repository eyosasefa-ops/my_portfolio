<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Symfony\Component\Mailer\Exception\TransportExceptionInterface;

class ContactController extends Controller
{
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email:rfc', 'max:254'],
            'subject' => ['required', 'string', 'max:150'],
            'inquiry_type' => ['required', 'string', Rule::in(config('portfolio.inquiry_types'))],
            'message' => ['required', 'string', 'min:10', 'max:5000'],
            'website' => ['nullable', 'string', 'max:0'],
        ]);

        $recipient = config('portfolio.contact_email');

        if (! $recipient) {
            return back()
                ->withInput($request->except('website'))
                ->with('contact_error', 'Contact delivery is not configured yet. Please use the email address shown above.');
        }

        $body = implode("\n", [
            'Name: '.$data['name'],
            'Email: '.$data['email'],
            'Inquiry type: '.$data['inquiry_type'],
            'Subject: '.$data['subject'],
            '',
            $data['message'],
        ]);

        try {
            Mail::raw($body, function ($mail) use ($data, $recipient): void {
                $mail->to($recipient)
                    ->replyTo($data['email'], $data['name'])
                    ->subject($data['subject']);
            });
        } catch (TransportExceptionInterface $exception) {
            report($exception);

            return back()
                ->withInput($request->except('website'))
                ->with('contact_error', 'Your message could not be sent. Please try again later or email me directly.');
        }

        $successMessage = config('mail.default') === 'log'
            ? 'Your message was recorded in the local mail log. Configure a delivery mailer to send it to me.'
            : 'Thanks for reaching out. Your message has been sent.';

        return back()->with('contact_success', $successMessage);
    }
}
