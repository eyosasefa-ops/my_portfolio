# Abera Asefa — Portfolio

A responsive, single-page personal portfolio built with Laravel, Blade, plain CSS, and vanilla JavaScript. The page is server-rendered; no React or frontend build step is required.

## Requirements

- PHP 8.3 or newer with PDO MySQL enabled
- Composer
- MySQL or MariaDB (only needed for features that persist data)

## Run locally on Windows

1. Open the project folder in VS Code and open a PowerShell terminal.
2. Install the PHP dependencies:

   ```powershell
   composer install
   ```

3. Create your local environment file if it does not already exist:

   ```powershell
   Copy-Item .env.example .env
   ```

4. The example environment is configured with `DB_DATABASE=portfolio`. A database is not needed for the current portfolio features. If you later add persistent data, create it in MySQL (for example, from the Herd database tools or your MySQL client):

   ```sql
   CREATE DATABASE portfolio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

5. If you do add persistent features, set `DB_HOST`, `DB_PORT`, `DB_USERNAME`, and `DB_PASSWORD` in `.env` to match your local MySQL server. Generate the Laravel application key:

   ```powershell
   php artisan key:generate
   ```

   The current portfolio uses file-based sessions and cache, so database migrations are not required to run it.

6. Configure `CONTACT_EMAIL`, `MAIL_MAILER`, and the corresponding mail settings in `.env` if you want the contact form to deliver messages. Set the displayed email and optional profile details there too (see **Customize the portfolio**).
7. Start the local server:

   ```powershell
   php artisan serve
   ```

   Open the URL printed by Artisan, usually `http://127.0.0.1:8000`.

The contact form validates input on the server, uses a honeypot field and request throttling, and sends through Laravel's configured mail transport. Without `CONTACT_EMAIL` configured, it displays a clear setup message rather than pretending a message was delivered. Laravel's default `log` mailer records messages locally instead of delivering them; the form says so, and the log can be found under `storage/logs`. Configure a real mail transport for actual delivery.

## Customize the portfolio

The portfolio data lives in `config/portfolio.php` and can be edited directly. Update the owner name, title, introduction, skill groups, project problems/objectives/contributions, and education information there. Bule Hora University and Software Engineering student status are the current editable defaults; do not add an expected graduation year, awards, or experience unless they are accurate. Skill groups distinguish foundations, current learning, and interests. Project technology lists are marked as suggestions or relevant technologies; update them to reflect the actual implementation before publishing. The profile photo is stored at `public/images/abera-profile.png`; `PORTFOLIO_PHOTO_PATH` in `.env` controls which image the hero displays. Add GitHub and live-demo URLs only when those links are real.

Optional environment settings in `.env`:

| Variable | Purpose |
| --- | --- |
| `PORTFOLIO_PHONE` | Public phone number used by call and copy buttons |
| `PORTFOLIO_EMAIL` | Public email address used in email and copy buttons |
| `CONTACT_EMAIL` | Recipient for contact form submissions |
| `PORTFOLIO_LOCATION` | Public city/region shown with a map search link |
| `PORTFOLIO_GITHUB_URL` | GitHub profile URL |
| `PORTFOLIO_LINKEDIN_URL` | LinkedIn profile URL |
| `PORTFOLIO_CV_PATH` | Path under `public/` to a real PDF, for example `files/abera-cv.pdf` |
| `PORTFOLIO_PHOTO_PATH` | Path under `public/` to a profile photo |
| `PORTFOLIO_INSTITUTION` | Institution name |
| `PORTFOLIO_EDUCATION_STATUS` | Current year or graduation status |

The theme preference is saved in the browser. To add a CV or photo, place the file under `public/` and set the matching path to its relative path. The CV section links to a download only if the configured PDF exists; otherwise it explains that a file is not available. The contact form requires an inquiry type selected from the configured list and includes it in the message delivered to `CONTACT_EMAIL`. The default `log` mailer records the message locally rather than emailing it; configure a working mail transport in `.env` for real email delivery. Never put SMTP passwords or other secrets in frontend files or commit a populated `.env`.

## GitHub and deployment

To publish this folder in a new GitHub repository:

```powershell
git init
git add .
git commit -m "Build personal portfolio"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Deploy to a PHP host that supports the installed Laravel version. Configure the production environment variables and MySQL database in the hosting dashboard, set `APP_ENV=production`, `APP_DEBUG=false`, generate a unique `APP_KEY`, and point the web server document root to Laravel's `public` directory. Run migrations during deployment and use `php artisan config:cache`. Set up a production mail transport before enabling the contact form.

## Testing and troubleshooting

Run the test suite with:

```powershell
php artisan test
```

- **Database connection errors:** Make sure the MySQL service is running, the `portfolio` database exists, and `.env` credentials match your server.
- **Contact form setup message:** Set `CONTACT_EMAIL`; configure the Laravel mail transport using environment variables.
- **Composer certificate errors:** If Herd's PHP reports `curl error 60` while Windows `curl.exe` works and Avast HTTPS scanning is enabled, add the Windows-trusted Avast Web/Mail Shield root certificate to a separate Composer CA bundle. Keep Composer TLS verification enabled; do not set `disable-tls`.
