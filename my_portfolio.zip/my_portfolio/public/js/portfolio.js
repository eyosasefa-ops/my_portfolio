const root = document.documentElement;
const themeToggle = document.querySelector('.theme-toggle');
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
const projectGrid = document.querySelector('#project-grid');
const projectSearch = document.querySelector('#project-search');
const emptyProjects = document.querySelector('#empty-projects');
const projectDialog = document.querySelector('.project-dialog');
const backToTop = document.querySelector('.back-to-top');

const storedTheme = localStorage.getItem('portfolio-theme');
const preferredTheme = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
root.dataset.theme = storedTheme || preferredTheme;

function updateThemeButton() {
    const isLight = root.dataset.theme === 'light';
    themeToggle.setAttribute('aria-label', isLight ? 'Switch to dark theme' : 'Switch to light theme');
    themeToggle.querySelector('.theme-icon').textContent = isLight ? '☾' : '☼';
}

updateThemeButton();

themeToggle.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('portfolio-theme', root.dataset.theme);
    updateThemeButton();
});

menuToggle.addEventListener('click', () => {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Open navigation menu' : 'Close navigation menu');
    navLinks.classList.toggle('is-open', !isOpen);
});

navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('is-open');
        menuToggle.setAttribute('aria-expanded', 'false');
        menuToggle.setAttribute('aria-label', 'Open navigation menu');
    });
});

const filterButtons = document.querySelectorAll('.filter-button');
let activeFilter = 'all';

function filterProjects() {
    const query = projectSearch.value.trim().toLowerCase();
    let visibleCount = 0;

    projectGrid.querySelectorAll('.project-card').forEach((card) => {
        const matchesCategory = activeFilter === 'all' || card.dataset.category === activeFilter;
        const matchesSearch = card.dataset.search.includes(query);
        const isVisible = matchesCategory && matchesSearch;
        card.hidden = !isVisible;
        visibleCount += Number(isVisible);
    });

    emptyProjects.hidden = visibleCount > 0;
}

filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
        activeFilter = button.dataset.filter;
        filterButtons.forEach((filter) => {
            const isActive = filter === button;
            filter.classList.toggle('is-active', isActive);
            filter.setAttribute('aria-pressed', String(isActive));
        });
        filterProjects();
    });
});

projectSearch.addEventListener('input', filterProjects);

document.querySelectorAll('.project-details-button').forEach((button) => {
    button.addEventListener('click', () => {
        projectDialog.querySelector('#dialog-title').textContent = button.dataset.title;
        projectDialog.querySelector('.dialog-description').textContent = button.dataset.details;
        projectDialog.querySelector('.dialog-problem').textContent = button.dataset.problem;
        projectDialog.querySelector('.dialog-objective').textContent = button.dataset.objective;
        projectDialog.querySelector('.dialog-contribution').textContent = button.dataset.contribution;
        projectDialog.querySelector('.dialog-stack').textContent = `${button.dataset.stackNote}: ${button.dataset.stack}`;
        const featureList = projectDialog.querySelector('.dialog-features');
        featureList.replaceChildren(...button.dataset.features.split('|').map((feature) => {
            const item = document.createElement('li');
            item.textContent = feature;
            return item;
        }));
        projectDialog.showModal();
        document.body.classList.add('dialog-open');
    });
});

function closeProjectDialog() {
    projectDialog.close();
    document.body.classList.remove('dialog-open');
}

projectDialog.querySelector('.dialog-close').addEventListener('click', closeProjectDialog);
projectDialog.addEventListener('click', (event) => {
    if (event.target === projectDialog) closeProjectDialog();
});
projectDialog.addEventListener('close', () => document.body.classList.remove('dialog-open'));

const contactForm = document.querySelector('.contact-form');
const copyFeedback = document.querySelector('#copy-feedback');

document.querySelectorAll('.copy-button').forEach((button) => {
    button.addEventListener('click', async () => {
        try {
            await navigator.clipboard.writeText(button.dataset.copy);
            copyFeedback.textContent = `${button.dataset.copyLabel.replace(/^Copy /, '')} copied.`;
            copyFeedback.classList.remove('is-error');
        } catch {
            copyFeedback.textContent = 'Copy is unavailable in this browser. Select and copy the contact detail instead.';
            copyFeedback.classList.add('is-error');
        }
    });
});

contactForm.addEventListener('submit', (event) => {
    if (!contactForm.reportValidity()) {
        event.preventDefault();
        return;
    }

    const button = contactForm.querySelector('.submit-button');
    button.disabled = true;
    button.querySelector('.submit-label').textContent = 'Sending…';
    contactForm.setAttribute('aria-busy', 'true');
});

document.querySelectorAll('.form-field input, .form-field textarea, .form-field select').forEach((field) => {
    field.addEventListener('input', () => {
        field.removeAttribute('aria-invalid');
        const error = document.querySelector(`#${field.id}-error`);
        if (error) error.remove();
    });
    field.addEventListener('change', () => {
        field.removeAttribute('aria-invalid');
        const error = document.querySelector(`#${field.id}-error`);
        if (error) error.remove();
    });
});

document.querySelectorAll('.field-error').forEach((error) => {
    const field = document.querySelector(`#${error.id.replace(/-error$/, '')}`);
    if (field) field.setAttribute('aria-invalid', 'true');
});

window.addEventListener('scroll', () => {
    backToTop.classList.toggle('is-visible', window.scrollY > 550);
}, { passive: true });

backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const current = navLinks.querySelector(`a[href="#${entry.target.id}"]`);
        navLinks.querySelectorAll('a').forEach((link) => link.classList.toggle('is-current', link === current));
    });
}, { rootMargin: '-30% 0px -60% 0px' });

document.querySelectorAll('main section[id]').forEach((section) => sectionObserver.observe(section));
